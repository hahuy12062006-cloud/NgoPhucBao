﻿Imports System.Collections.Generic
Imports System.Windows.Forms
Imports System.Windows.Forms.VisualStyles.VisualStyleElement.TrackBar

Public Class FormThuoc

    Private Enum FormState
        Normal
        Adding
        Editing
    End Enum

    Private currentState As FormState = FormState.Normal
    Private ReadOnly medicineManager As New ThuocBLL()

    Private Sub FormThuoc_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Khởi tạo ComboBox cmbNhaCungCap/Nhóm thuốc
        If cmbNhaCungCap.Items.Count = 0 Then
            ' Lấy từ bảng NHOM_THUOC hoặc NHA_CUNG_CAP trong CSDL
            cmbNhaCungCap.Items.AddRange({"Kháng Sinh (G02)", "Giảm Đau (G01)", "Vitamin"})
        End If
        LoadData()
    End Sub

    ' ------------------------------------------------------------------
    ' # HÀM HỖ TRỢ CHUNG
    ' ------------------------------------------------------------------

    Private Sub LoadData()
        Try
            dgvThuoc.DataSource = medicineManager.GetAllMedicines()
            currentState = FormState.Normal
            SetButtonAvailability(FormState.Normal)
            SetInputControlsEnabled(False)
            ClearInputFields()
        Catch ex As Exception
            MessageBox.Show("Lỗi tải dữ liệu: " & ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub SetInputControlsEnabled(enable As Boolean)
        ' Dựa trên các controls trong hình
        txtMaThuoc.ReadOnly = Not enable
        txtTenThuoc.ReadOnly = Not enable
        txtHoaChat.ReadOnly = Not enable
        txtDonVi.ReadOnly = Not enable ' DonViTinh
        txtGiaBan.ReadOnly = Not enable ' GiaBanLe
        txtSoLuong.ReadOnly = Not enable ' SoLuongTon
        dtpHanDung.Enabled = enable
        cmbNhaCungCap.Enabled = enable
    End Sub

    Private Sub SetButtonAvailability(state As FormState)
        ' Dựa trên các controls trong hình
        btnThem.Enabled = (state = FormState.Normal)
        btnTimKiem.Enabled = (state = FormState.Normal)

        Dim rowSelected As Boolean = dgvThuoc.SelectedRows.Count > 0
        btnSua.Enabled = (state = FormState.Normal AndAlso rowSelected)
        btnXoa.Enabled = (state = FormState.Normal AndAlso rowSelected)

        btnLuu.Enabled = (state = FormState.Adding OrElse state = FormState.Editing)
        btnHuy.Enabled = (state = FormState.Adding OrElse state = FormState.Editing)
    End Sub

    Private Sub ClearInputFields()
        txtMaThuoc.Clear()
        txtTenThuoc.Clear()
        txtHoatChat.Clear()
        txtDonVi.Clear()
        txtGiaBan.Clear()
        txtSoLuong.Clear()
        dtpHanDung.Value = Date.Now
        cmbNhaCungCap.SelectedIndex = -1
    End Sub

    Private Function GetThuocFromInputs() As Thuoc
        ' Kiểm tra nhập liệu và chuyển đổi kiểu dữ liệu
        If String.IsNullOrWhiteSpace(txtMaThuoc.Text) OrElse String.IsNullOrWhiteSpace(txtTenThuoc.Text) Then
            Throw New Exception("Mã thuốc và Tên thuốc không được để trống.")
        End If

        Dim giaBan As Decimal = 0D
        Dim soLuong As Integer = 0

        If Not Decimal.TryParse(txtGiaBan.Text, giaBan) Then
            Throw New Exception("Giá bán không hợp lệ.")
        End If

        If Not Integer.TryParse(txtSoLuong.Text, soLuong) Then
            Throw New Exception("Số lượng không hợp lệ.")
        End If

        ' Tạo đối tượng Thuoc
        Return New Thuoc With {
            .MaThuoc = txtMaThuoc.Text.Trim(),
            .TenThuoc = txtTenThuoc.Text.Trim(),
            .HoatChat = txtHoatChat.Text.Trim(),
            .DonViTinh = txtDonVi.Text.Trim(),
            .GiaBanLe = giaBan,
            .SoLuongTon = soLuong,
            .HanSuDung = dtpHanDung.Value,
            .MaNhom = cmbNhaCungCap.SelectedItem?.ToString().Split("(")(1).Replace(")", "") ' Lấy MaNhom
        }
    End Function

    ' ------------------------------------------------------------------
    ' # XỬ LÝ SỰ KIỆN (CRUD)
    ' ------------------------------------------------------------------

    Private Sub btnThem_Click(sender As Object, e As EventArgs) Handles btnThem.Click
        currentState = FormState.Adding
        ClearInputFields()
        SetInputControlsEnabled(True)
        SetButtonAvailability(FormState.Adding)
        txtMaThuoc.Focus()
    End Sub

    Private Sub btnSua_Click(sender As Object, e As EventArgs) Handles btnSua.Click
        If dgvThuoc.SelectedRows.Count > 0 Then
            currentState = FormState.Editing
            SetInputControlsEnabled(True)
            SetButtonAvailability(FormState.Editing)
            txtMaThuoc.ReadOnly = True
            txtTenThuoc.Focus()
        End If
    End Sub

    Private Sub btnXoa_Click(sender As Object, e As EventArgs) Handles btnXoa.Click
        If dgvThuoc.SelectedRows.Count > 0 AndAlso MessageBox.Show("Xóa thuốc này?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = DialogResult.Yes Then
            Try
                Dim maThuocToDelete As String = dgvThuoc.SelectedRows(0).Cells("MaThuoc").Value.ToString()
                medicineManager.DeleteMedicine(maThuocToDelete)
                LoadData()
            Catch ex As Exception
                MessageBox.Show("Lỗi xóa: " & ex.Message, "Lỗi")
            End Try
        End If
    End Sub

    Private Sub btnLuu_Click(sender As Object, e As EventArgs) Handles btnLuu.Click
        Try
            Dim data As Thuoc = GetThuocFromInputs()
            If currentState = FormState.Adding Then
                medicineManager.AddMedicine(data)
            ElseIf currentState = FormState.Editing Then
                medicineManager.UpdateMedicine(data)
            End If
            LoadData()
        Catch ex As Exception
            MessageBox.Show("Lỗi lưu dữ liệu: " & ex.Message, "Lỗi")
        End Try
    End Sub

    Private Sub btnHuy_Click(sender As Object, e As EventArgs) Handles btnHuy.Click
        LoadData()
    End Sub

    Private Sub btnTimKiem_Click(sender As Object, e As EventArgs) Handles btnTimKiem.Click
        ' Tìm kiếm theo tên/mã/hoạt chất
        Dim searchKeyword As String = txtTenThuoc.Text.Trim()

        If String.IsNullOrEmpty(searchKeyword) Then
            LoadData()
            Return
        End If

        Try
            dgvThuoc.DataSource = medicineManager.SearchMedicines(searchKeyword)
        Catch ex As Exception
            MessageBox.Show("Lỗi tìm kiếm: " & ex.Message, "Lỗi")
        End Try
    End Sub

    ' ------------------------------------------------------------------
    ' # TÍNH NĂNG NHẬP/XUẤT EXCEL (Placeholder)
    ' ------------------------------------------------------------------

    ' Bạn cần thêm nút và sự kiện cho tính năng này
    Private Sub btnXuatExcel_Click(sender As Object, e As EventArgs)
        MessageBox.Show("Tính năng Xuất Excel cần sử dụng thư viện như EPPlus hoặc Microsoft.Office.Interop.Excel để triển khai.", "Thông báo")
        ' CODE TO: Export data from dgvThuoc to an Excel file
    End Sub

    Private Sub btnNhapExcel_Click(sender As Object, e As EventArgs)
        MessageBox.Show("Tính năng Nhập Excel cần sử dụng thư viện như EPPlus hoặc Microsoft.Office.Interop.Excel để triển khai.", "Thông báo")
        ' CODE TO: Read data from an Excel file and insert/update the database
    End Sub

    ' ------------------------------------------------------------------
    ' # DATA GRID VIEW
    ' ------------------------------------------------------------------

    Private Sub dgvThuoc_SelectionChanged(sender As Object, e As EventArgs) Handles dgvThuoc.SelectionChanged
        If currentState = FormState.Normal And dgvThuoc.SelectedRows.Count > 0 Then
            Dim row As DataGridViewRow = dgvThuoc.SelectedRows(0)

            ' Nạp dữ liệu vào TextBoxes
            txtMaThuoc.Text = row.Cells("MaThuoc").Value?.ToString()
            txtTenThuoc.Text = row.Cells("TenThuoc").Value?.ToString()
            txtHoatChat.Text = row.Cells("HoatChat").Value?.ToString()

            ' Dùng DonViTinh (CSDL) cho txtDonVi (UI)
            txtDonVi.Text = row.Cells("DonViTinh").Value?.ToString()

            ' Dùng GiaBanLe (CSDL) cho txtGiaBan (UI)
            If row.Cells("GiaBanLe").Value IsNot Nothing Then txtGiaBan.Text = row.Cells("GiaBanLe").Value.ToString()

            ' SoLuongTon cho txtSoLuong
            If row.Cells("SoLuongTon").Value IsNot Nothing Then txtSoLuong.Text = row.Cells("SoLuongTon").Value.ToString()

            ' HanSuDung cho dtpHanDung
            If row.Cells("HanSuDung").Value IsNot Nothing AndAlso IsDate(row.Cells("HanSuDung").Value) Then
                dtpHanDung.Value = CDate(row.Cells("HanSuDung").Value)
            End If

            ' Hiển thị MaNhom (ví dụ)
            Dim maNhom As String = row.Cells("MaNhom").Value?.ToString()
            For i As Integer = 0 To cmbNhaCungCap.Items.Count - 1
                If cmbNhaCungCap.Items(i).ToString().Contains(maNhom) Then
                    cmbNhaCungCap.SelectedIndex = i
                    Exit For
                End If
            Next

            SetButtonAvailability(FormState.Normal)
        End If
    End Sub
End Class