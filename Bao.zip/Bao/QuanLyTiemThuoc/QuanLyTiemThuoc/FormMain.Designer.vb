﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.pnlContent = New System.Windows.Forms.Panel()
        Me.statusBar = New System.Windows.Forms.StatusStrip()
        Me.btnThuoc = New System.Windows.Forms.Button()
        Me.btnBanHang = New System.Windows.Forms.Button()
        Me.btnNhapHang = New System.Windows.Forms.Button()
        Me.btnThongKe = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(750, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'pnlContent
        '
        Me.pnlContent.Location = New System.Drawing.Point(121, 183)
        Me.pnlContent.Name = "pnlContent"
        Me.pnlContent.Size = New System.Drawing.Size(200, 100)
        Me.pnlContent.TabIndex = 1
        '
        'statusBar
        '
        Me.statusBar.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.statusBar.Location = New System.Drawing.Point(0, 404)
        Me.statusBar.Name = "statusBar"
        Me.statusBar.Size = New System.Drawing.Size(750, 22)
        Me.statusBar.TabIndex = 4
        Me.statusBar.Text = "StatusStrip3"
        '
        'btnThuoc
        '
        Me.btnThuoc.Location = New System.Drawing.Point(540, 88)
        Me.btnThuoc.Name = "btnThuoc"
        Me.btnThuoc.Size = New System.Drawing.Size(103, 23)
        Me.btnThuoc.TabIndex = 5
        Me.btnThuoc.Text = "Thuốc"
        Me.btnThuoc.UseVisualStyleBackColor = True
        '
        'btnBanHang
        '
        Me.btnBanHang.Location = New System.Drawing.Point(540, 159)
        Me.btnBanHang.Name = "btnBanHang"
        Me.btnBanHang.Size = New System.Drawing.Size(103, 23)
        Me.btnBanHang.TabIndex = 6
        Me.btnBanHang.Text = "Bán hàng"
        Me.btnBanHang.UseVisualStyleBackColor = True
        '
        'btnNhapHang
        '
        Me.btnNhapHang.Location = New System.Drawing.Point(540, 236)
        Me.btnNhapHang.Name = "btnNhapHang"
        Me.btnNhapHang.Size = New System.Drawing.Size(103, 23)
        Me.btnNhapHang.TabIndex = 7
        Me.btnNhapHang.Text = "Nhập hàng"
        Me.btnNhapHang.UseVisualStyleBackColor = True
        '
        'btnThongKe
        '
        Me.btnThongKe.Location = New System.Drawing.Point(540, 312)
        Me.btnThongKe.Name = "btnThongKe"
        Me.btnThongKe.Size = New System.Drawing.Size(103, 23)
        Me.btnThongKe.TabIndex = 8
        Me.btnThongKe.Text = "Thống kê"
        Me.btnThongKe.UseVisualStyleBackColor = True
        '
        'FormMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(750, 426)
        Me.Controls.Add(Me.btnThongKe)
        Me.Controls.Add(Me.btnNhapHang)
        Me.Controls.Add(Me.btnBanHang)
        Me.Controls.Add(Me.btnThuoc)
        Me.Controls.Add(Me.statusBar)
        Me.Controls.Add(Me.pnlContent)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "FormMain"
        Me.Text = "FormMain"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents pnlContent As Panel
    Friend WithEvents statusBar As StatusStrip
    Friend WithEvents btnThuoc As Button
    Friend WithEvents btnBanHang As Button
    Friend WithEvents btnNhapHang As Button
    Friend WithEvents btnThongKe As Button
End Class
