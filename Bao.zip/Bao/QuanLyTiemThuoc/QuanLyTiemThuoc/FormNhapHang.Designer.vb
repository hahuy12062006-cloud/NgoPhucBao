﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormNhapHang
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dgvChiTietPhieuNhap = New System.Windows.Forms.DataGridView()
        Me.dgvThuoc = New System.Windows.Forms.DataGridView()
        Me.txtMaThuoc = New System.Windows.Forms.TextBox()
        Me.txtTenThuoc = New System.Windows.Forms.TextBox()
        Me.txtHoaChat = New System.Windows.Forms.TextBox()
        Me.txtDonVi = New System.Windows.Forms.TextBox()
        Me.txtGiaBan = New System.Windows.Forms.TextBox()
        Me.txtSoLuong = New System.Windows.Forms.TextBox()
        Me.cmbNhaCungCap = New System.Windows.Forms.ComboBox()
        Me.dtpHanDung = New System.Windows.Forms.DateTimePicker()
        Me.btnThem = New System.Windows.Forms.Button()
        Me.btnSua = New System.Windows.Forms.Button()
        Me.btnXoa = New System.Windows.Forms.Button()
        Me.btnLuu = New System.Windows.Forms.Button()
        Me.btnHuy = New System.Windows.Forms.Button()
        Me.btnTimKiem = New System.Windows.Forms.Button()
        CType(Me.dgvChiTietPhieuNhap, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvThuoc, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvChiTietPhieuNhap
        '
        Me.dgvChiTietPhieuNhap.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvChiTietPhieuNhap.Location = New System.Drawing.Point(627, 33)
        Me.dgvChiTietPhieuNhap.Name = "dgvChiTietPhieuNhap"
        Me.dgvChiTietPhieuNhap.RowHeadersWidth = 51
        Me.dgvChiTietPhieuNhap.RowTemplate.Height = 24
        Me.dgvChiTietPhieuNhap.Size = New System.Drawing.Size(211, 103)
        Me.dgvChiTietPhieuNhap.TabIndex = 0
        '
        'dgvThuoc
        '
        Me.dgvThuoc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvThuoc.Location = New System.Drawing.Point(214, 33)
        Me.dgvThuoc.Name = "dgvThuoc"
        Me.dgvThuoc.RowHeadersWidth = 51
        Me.dgvThuoc.RowTemplate.Height = 24
        Me.dgvThuoc.Size = New System.Drawing.Size(240, 150)
        Me.dgvThuoc.TabIndex = 1
        '
        'txtMaThuoc
        '
        Me.txtMaThuoc.Location = New System.Drawing.Point(61, 246)
        Me.txtMaThuoc.Name = "txtMaThuoc"
        Me.txtMaThuoc.Size = New System.Drawing.Size(126, 22)
        Me.txtMaThuoc.TabIndex = 2
        '
        'txtTenThuoc
        '
        Me.txtTenThuoc.Location = New System.Drawing.Point(47, 308)
        Me.txtTenThuoc.Name = "txtTenThuoc"
        Me.txtTenThuoc.Size = New System.Drawing.Size(156, 22)
        Me.txtTenThuoc.TabIndex = 3
        '
        'txtHoaChat
        '
        Me.txtHoaChat.Location = New System.Drawing.Point(61, 374)
        Me.txtHoaChat.Name = "txtHoaChat"
        Me.txtHoaChat.Size = New System.Drawing.Size(156, 22)
        Me.txtHoaChat.TabIndex = 5
        '
        'txtDonVi
        '
        Me.txtDonVi.Location = New System.Drawing.Point(61, 435)
        Me.txtDonVi.Name = "txtDonVi"
        Me.txtDonVi.Size = New System.Drawing.Size(129, 22)
        Me.txtDonVi.TabIndex = 6
        '
        'txtGiaBan
        '
        Me.txtGiaBan.Location = New System.Drawing.Point(71, 490)
        Me.txtGiaBan.Name = "txtGiaBan"
        Me.txtGiaBan.Size = New System.Drawing.Size(156, 22)
        Me.txtGiaBan.TabIndex = 7
        '
        'txtSoLuong
        '
        Me.txtSoLuong.Location = New System.Drawing.Point(61, 553)
        Me.txtSoLuong.Name = "txtSoLuong"
        Me.txtSoLuong.Size = New System.Drawing.Size(156, 22)
        Me.txtSoLuong.TabIndex = 8
        '
        'cmbNhaCungCap
        '
        Me.cmbNhaCungCap.FormattingEnabled = True
        Me.cmbNhaCungCap.Location = New System.Drawing.Point(340, 267)
        Me.cmbNhaCungCap.Name = "cmbNhaCungCap"
        Me.cmbNhaCungCap.Size = New System.Drawing.Size(147, 24)
        Me.cmbNhaCungCap.TabIndex = 9
        '
        'dtpHanDung
        '
        Me.dtpHanDung.Location = New System.Drawing.Point(285, 418)
        Me.dtpHanDung.Name = "dtpHanDung"
        Me.dtpHanDung.Size = New System.Drawing.Size(245, 22)
        Me.dtpHanDung.TabIndex = 10
        '
        'btnThem
        '
        Me.btnThem.Location = New System.Drawing.Point(840, 230)
        Me.btnThem.Name = "btnThem"
        Me.btnThem.Size = New System.Drawing.Size(115, 38)
        Me.btnThem.TabIndex = 11
        Me.btnThem.Text = "Thêm"
        Me.btnThem.UseVisualStyleBackColor = True
        '
        'btnSua
        '
        Me.btnSua.Location = New System.Drawing.Point(840, 292)
        Me.btnSua.Name = "btnSua"
        Me.btnSua.Size = New System.Drawing.Size(115, 38)
        Me.btnSua.TabIndex = 12
        Me.btnSua.Text = "Sửa"
        Me.btnSua.UseVisualStyleBackColor = True
        '
        'btnXoa
        '
        Me.btnXoa.Location = New System.Drawing.Point(840, 358)
        Me.btnXoa.Name = "btnXoa"
        Me.btnXoa.Size = New System.Drawing.Size(115, 38)
        Me.btnXoa.TabIndex = 13
        Me.btnXoa.Text = "Xóa"
        Me.btnXoa.UseVisualStyleBackColor = True
        '
        'btnLuu
        '
        Me.btnLuu.Location = New System.Drawing.Point(840, 427)
        Me.btnLuu.Name = "btnLuu"
        Me.btnLuu.Size = New System.Drawing.Size(115, 38)
        Me.btnLuu.TabIndex = 14
        Me.btnLuu.Text = "Lưu"
        Me.btnLuu.UseVisualStyleBackColor = True
        '
        'btnHuy
        '
        Me.btnHuy.Location = New System.Drawing.Point(840, 474)
        Me.btnHuy.Name = "btnHuy"
        Me.btnHuy.Size = New System.Drawing.Size(115, 38)
        Me.btnHuy.TabIndex = 15
        Me.btnHuy.Text = "Hủy"
        Me.btnHuy.UseVisualStyleBackColor = True
        '
        'btnTimKiem
        '
        Me.btnTimKiem.Location = New System.Drawing.Point(849, 527)
        Me.btnTimKiem.Name = "btnTimKiem"
        Me.btnTimKiem.Size = New System.Drawing.Size(115, 38)
        Me.btnTimKiem.TabIndex = 16
        Me.btnTimKiem.Text = "Tìm kiếm"
        Me.btnTimKiem.UseVisualStyleBackColor = True
        '
        'FormNhapHang
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1034, 587)
        Me.Controls.Add(Me.btnTimKiem)
        Me.Controls.Add(Me.btnHuy)
        Me.Controls.Add(Me.btnLuu)
        Me.Controls.Add(Me.btnXoa)
        Me.Controls.Add(Me.btnSua)
        Me.Controls.Add(Me.btnThem)
        Me.Controls.Add(Me.dtpHanDung)
        Me.Controls.Add(Me.cmbNhaCungCap)
        Me.Controls.Add(Me.txtSoLuong)
        Me.Controls.Add(Me.txtGiaBan)
        Me.Controls.Add(Me.txtDonVi)
        Me.Controls.Add(Me.txtHoaChat)
        Me.Controls.Add(Me.txtTenThuoc)
        Me.Controls.Add(Me.txtMaThuoc)
        Me.Controls.Add(Me.dgvThuoc)
        Me.Controls.Add(Me.dgvChiTietPhieuNhap)
        Me.Name = "FormNhapHang"
        Me.Text = "FormNhapHang"
        CType(Me.dgvChiTietPhieuNhap, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvThuoc, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents dgvChiTietPhieuNhap As DataGridView
    Friend WithEvents dgvThuoc As DataGridView
    Friend WithEvents txtMaThuoc As TextBox
    Friend WithEvents txtTenThuoc As TextBox
    Friend WithEvents txtHoaChat As TextBox
    Friend WithEvents txtDonVi As TextBox
    Friend WithEvents txtGiaBan As TextBox
    Friend WithEvents txtSoLuong As TextBox
    Friend WithEvents cmbNhaCungCap As ComboBox
    Friend WithEvents dtpHanDung As DateTimePicker
    Friend WithEvents btnThem As Button
    Friend WithEvents btnSua As Button
    Friend WithEvents btnXoa As Button
    Friend WithEvents btnLuu As Button
    Friend WithEvents btnHuy As Button
    Friend WithEvents btnTimKiem As Button
End Class
