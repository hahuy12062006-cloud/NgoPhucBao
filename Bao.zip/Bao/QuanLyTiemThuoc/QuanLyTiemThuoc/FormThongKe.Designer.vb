﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormThongKe
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cmbLoaiBaoCao = New System.Windows.Forms.ComboBox()
        Me.btnXemBaoCao = New System.Windows.Forms.Button()
        Me.dgvBaoCao = New System.Windows.Forms.DataGridView()
        Me.dtpFrom = New System.Windows.Forms.DateTimePicker()
        Me.dtpTo = New System.Windows.Forms.DateTimePicker()
        CType(Me.dgvBaoCao, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmbLoaiBaoCao
        '
        Me.cmbLoaiBaoCao.FormattingEnabled = True
        Me.cmbLoaiBaoCao.Location = New System.Drawing.Point(137, 211)
        Me.cmbLoaiBaoCao.Name = "cmbLoaiBaoCao"
        Me.cmbLoaiBaoCao.Size = New System.Drawing.Size(177, 24)
        Me.cmbLoaiBaoCao.TabIndex = 2
        '
        'btnXemBaoCao
        '
        Me.btnXemBaoCao.Location = New System.Drawing.Point(498, 223)
        Me.btnXemBaoCao.Name = "btnXemBaoCao"
        Me.btnXemBaoCao.Size = New System.Drawing.Size(184, 63)
        Me.btnXemBaoCao.TabIndex = 3
        Me.btnXemBaoCao.Text = "Xem báo cáo"
        Me.btnXemBaoCao.UseVisualStyleBackColor = True
        '
        'dgvBaoCao
        '
        Me.dgvBaoCao.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvBaoCao.Location = New System.Drawing.Point(238, 305)
        Me.dgvBaoCao.Name = "dgvBaoCao"
        Me.dgvBaoCao.RowHeadersWidth = 51
        Me.dgvBaoCao.RowTemplate.Height = 24
        Me.dgvBaoCao.Size = New System.Drawing.Size(218, 66)
        Me.dgvBaoCao.TabIndex = 4
        '
        'dtpFrom
        '
        Me.dtpFrom.Location = New System.Drawing.Point(85, 73)
        Me.dtpFrom.Name = "dtpFrom"
        Me.dtpFrom.Size = New System.Drawing.Size(239, 22)
        Me.dtpFrom.TabIndex = 5
        '
        'dtpTo
        '
        Me.dtpTo.Location = New System.Drawing.Point(450, 73)
        Me.dtpTo.Name = "dtpTo"
        Me.dtpTo.Size = New System.Drawing.Size(232, 22)
        Me.dtpTo.TabIndex = 6
        '
        'FormThongKe
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.dtpTo)
        Me.Controls.Add(Me.dtpFrom)
        Me.Controls.Add(Me.dgvBaoCao)
        Me.Controls.Add(Me.btnXemBaoCao)
        Me.Controls.Add(Me.cmbLoaiBaoCao)
        Me.Name = "FormThongKe"
        Me.Text = "FormThongKe"
        CType(Me.dgvBaoCao, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents cmbLoaiBaoCao As ComboBox
    Friend WithEvents btnXemBaoCao As Button
    Friend WithEvents dgvBaoCao As DataGridView
    Friend WithEvents dtpFrom As DateTimePicker
    Friend WithEvents dtpTo As DateTimePicker
End Class
