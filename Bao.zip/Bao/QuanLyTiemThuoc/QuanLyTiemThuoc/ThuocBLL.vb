﻿Friend Class ThuocBLL
    Public Sub New()
    End Sub
End Class
