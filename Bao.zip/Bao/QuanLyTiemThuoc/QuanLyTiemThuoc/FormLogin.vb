﻿Imports System.Data.SqlClient

Public Class FormLogin

    Dim conn As New SqlConnection("Data Source=LAPTOP-EE4MDLC5\SQLEXPRESS;Initial Catalog=QuanLyTiemThuoc;Integrated Security=True;")

    Private Sub FormLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    End Sub

    Private Sub btnDangNhap_Click(sender As Object, e As EventArgs) Handles btnDangNhap.Click
        Try
            ' Mở kết nối nếu đang đóng
            If conn.State = ConnectionState.Closed Then
                conn.Open()
            End If

            ' Truy vấn kiểm tra tài khoản và mật khẩu
            Dim da As New SqlDataAdapter("SELECT * FROM Table_Users WHERE TaiKhoan=@tk AND MatKhau=@mk", conn)
            da.SelectCommand.Parameters.AddWithValue("@tk", txtTaiKhoan.Text)
            da.SelectCommand.Parameters.AddWithValue("@mk", txtMatKhau.Text)

            Dim dt As New DataTable()
            da.Fill(dt)

            If dt.Rows.Count > 0 Then
                Dim email As String = dt.Rows(0)("Email").ToString()
                MsgBox("Đăng nhập thành công!" & vbCrLf & "Email: " & email, vbInformation)

                ' Mở form chính sau khi đăng nhập thành công
                Dim f As New FormMain()
                f.Show()
                Me.Hide()
            Else
                MsgBox("Sai tài khoản hoặc mật khẩu!", vbCritical)
            End If

        Catch ex As Exception
            MsgBox("Lỗi: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub btnQuenMK_Click(sender As Object, e As EventArgs) Handles btnQuenMK.Click
        Dim f As New FormForgotPassword()
        f.ShowDialog()
    End Sub

    Private Sub btnThoat_Click(sender As Object, e As EventArgs) Handles btnThoat.Click
        Me.Close()
    End Sub
End Class
