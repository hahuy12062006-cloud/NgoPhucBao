﻿Imports System.Data.SqlClient

Public Class FormForgotPassword
    Dim conn As New SqlConnection("Data Source=.\SQLEXPRESS;Initial Catalog=QuanLyTiemThuoc;Integrated Security=True")
    Private Sub FormForgotPassword_Load(sender As Object, e As EventArgs) Handles MyBase.Load


    End Sub

    Private Sub btnLayMK_Click(sender As Object, e As EventArgs) Handles btnLayMK.Click
        Dim da As New SqlDataAdapter("SELECT MatKhau FROM Table_Users WHERE TaiKhoan=@tk AND Email=@em", conn)
        da.SelectCommand.Parameters.AddWithValue("@tk", txtTaiKhoan.Text)
        da.SelectCommand.Parameters.AddWithValue("@em", txtEmail.Text)

        Dim dt As New DataTable()
        da.Fill(dt)

        If dt.Rows.Count > 0 Then
            MsgBox("Mật khẩu của bạn là: " & dt.Rows(0)("MatKhau").ToString(), vbInformation)
        Else
            MsgBox("Không tìm thấy tài khoản hoặc email không khớp!", vbCritical)
        End If


    End Sub
End Class