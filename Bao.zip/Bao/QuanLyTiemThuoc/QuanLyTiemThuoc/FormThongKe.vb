﻿Public Class FormThongKe
    Private Sub DateTimePicker2_ValueChanged(sender As Object, e As EventArgs) Handles dtpTo.ValueChanged

    End Sub
End Class