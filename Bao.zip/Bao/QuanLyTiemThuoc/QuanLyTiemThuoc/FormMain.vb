﻿Public Class FormMain

    Private Sub FormMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Text = "Phần mềm Quản lý Tiệm Thuốc"
    End Sub

    Private Sub btnThuoc_Click(sender As Object, e As EventArgs) Handles btnThuoc.Click
        Dim f As New FormThuoc
        f.ShowDialog()
    End Sub

    Private Sub btnBanHang_Click(sender As Object, e As EventArgs) Handles btnBanHang.Click
        Dim f As New FormBanHang
        f.ShowDialog()
    End Sub

    Private Sub btnNhapHang_Click(sender As Object, e As EventArgs) Handles btnNhapHang.Click
        Dim f As New FormNhapHang
        f.ShowDialog()
    End Sub

    Private Sub btnThongKe_Click(sender As Object, e As EventArgs) Handles btnThongKe.Click
        Dim f As New FormThongKe
        f.ShowDialog()
    End Sub
End Class
