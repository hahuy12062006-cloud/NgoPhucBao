﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormBanHang
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtSearchThuoc = New System.Windows.Forms.TextBox()
        Me.dgvGioHang = New System.Windows.Forms.DataGridView()
        Me.nudSoLuong = New System.Windows.Forms.NumericUpDown()
        Me.lblTongTien = New System.Windows.Forms.Label()
        Me.btnThemVaoGio = New System.Windows.Forms.Button()
        Me.btnXoaKhoiGio = New System.Windows.Forms.Button()
        Me.btnThanhToan = New System.Windows.Forms.Button()
        Me.btnInHoaDon = New System.Windows.Forms.Button()
        CType(Me.dgvGioHang, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudSoLuong, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtSearchThuoc
        '
        Me.txtSearchThuoc.Location = New System.Drawing.Point(296, 285)
        Me.txtSearchThuoc.Name = "txtSearchThuoc"
        Me.txtSearchThuoc.Size = New System.Drawing.Size(162, 22)
        Me.txtSearchThuoc.TabIndex = 0
        '
        'dgvGioHang
        '
        Me.dgvGioHang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvGioHang.Location = New System.Drawing.Point(286, 123)
        Me.dgvGioHang.Name = "dgvGioHang"
        Me.dgvGioHang.RowHeadersWidth = 51
        Me.dgvGioHang.RowTemplate.Height = 24
        Me.dgvGioHang.Size = New System.Drawing.Size(182, 36)
        Me.dgvGioHang.TabIndex = 1
        '
        'nudSoLuong
        '
        Me.nudSoLuong.Location = New System.Drawing.Point(296, 227)
        Me.nudSoLuong.Name = "nudSoLuong"
        Me.nudSoLuong.Size = New System.Drawing.Size(146, 22)
        Me.nudSoLuong.TabIndex = 2
        '
        'lblTongTien
        '
        Me.lblTongTien.AutoSize = True
        Me.lblTongTien.Location = New System.Drawing.Point(335, 47)
        Me.lblTongTien.Name = "lblTongTien"
        Me.lblTongTien.Size = New System.Drawing.Size(63, 16)
        Me.lblTongTien.TabIndex = 3
        Me.lblTongTien.Text = "Tổng tiền"
        '
        'btnThemVaoGio
        '
        Me.btnThemVaoGio.Location = New System.Drawing.Point(639, 178)
        Me.btnThemVaoGio.Name = "btnThemVaoGio"
        Me.btnThemVaoGio.Size = New System.Drawing.Size(115, 41)
        Me.btnThemVaoGio.TabIndex = 4
        Me.btnThemVaoGio.Text = "Thêm vào giỏ"
        Me.btnThemVaoGio.UseVisualStyleBackColor = True
        '
        'btnXoaKhoiGio
        '
        Me.btnXoaKhoiGio.Location = New System.Drawing.Point(639, 243)
        Me.btnXoaKhoiGio.Name = "btnXoaKhoiGio"
        Me.btnXoaKhoiGio.Size = New System.Drawing.Size(115, 38)
        Me.btnXoaKhoiGio.TabIndex = 10
        Me.btnXoaKhoiGio.Text = "Xóa khỏi giỏ"
        Me.btnXoaKhoiGio.UseVisualStyleBackColor = True
        '
        'btnThanhToan
        '
        Me.btnThanhToan.Location = New System.Drawing.Point(639, 312)
        Me.btnThanhToan.Name = "btnThanhToan"
        Me.btnThanhToan.Size = New System.Drawing.Size(115, 38)
        Me.btnThanhToan.TabIndex = 11
        Me.btnThanhToan.Text = "Thanh toán"
        Me.btnThanhToan.UseVisualStyleBackColor = True
        '
        'btnInHoaDon
        '
        Me.btnInHoaDon.Location = New System.Drawing.Point(639, 381)
        Me.btnInHoaDon.Name = "btnInHoaDon"
        Me.btnInHoaDon.Size = New System.Drawing.Size(115, 38)
        Me.btnInHoaDon.TabIndex = 12
        Me.btnInHoaDon.Text = "In hóa đơn"
        Me.btnInHoaDon.UseVisualStyleBackColor = True
        '
        'FormBanHang
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnInHoaDon)
        Me.Controls.Add(Me.btnThanhToan)
        Me.Controls.Add(Me.btnXoaKhoiGio)
        Me.Controls.Add(Me.btnThemVaoGio)
        Me.Controls.Add(Me.lblTongTien)
        Me.Controls.Add(Me.nudSoLuong)
        Me.Controls.Add(Me.dgvGioHang)
        Me.Controls.Add(Me.txtSearchThuoc)
        Me.Name = "FormBanHang"
        Me.Text = "FormBanHang"
        CType(Me.dgvGioHang, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudSoLuong, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtSearchThuoc As TextBox
    Friend WithEvents dgvGioHang As DataGridView
    Friend WithEvents nudSoLuong As NumericUpDown
    Friend WithEvents lblTongTien As Label
    Friend WithEvents btnThemVaoGio As Button
    Friend WithEvents btnXoaKhoiGio As Button
    Friend WithEvents btnThanhToan As Button
    Friend WithEvents btnInHoaDon As Button
End Class
