﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormThuoc
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dgvThuoc = New System.Windows.Forms.DataGridView()
        Me.txtMaThuoc = New System.Windows.Forms.TextBox()
        Me.txtTenThuoc = New System.Windows.Forms.TextBox()
        Me.txtDonVi = New System.Windows.Forms.TextBox()
        Me.txtHoaChat = New System.Windows.Forms.TextBox()
        Me.txtGiaBan = New System.Windows.Forms.TextBox()
        Me.txtSoLuong = New System.Windows.Forms.TextBox()
        Me.dtpHanDung = New System.Windows.Forms.DateTimePicker()
        Me.cmbNhaCungCap = New System.Windows.Forms.ComboBox()
        Me.btnThem = New System.Windows.Forms.Button()
        Me.btnSua = New System.Windows.Forms.Button()
        Me.btnXoa = New System.Windows.Forms.Button()
        Me.btnLuu = New System.Windows.Forms.Button()
        Me.btnHuy = New System.Windows.Forms.Button()
        Me.btnTimKiem = New System.Windows.Forms.Button()
        CType(Me.dgvThuoc, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvThuoc
        '
        Me.dgvThuoc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvThuoc.Location = New System.Drawing.Point(257, 12)
        Me.dgvThuoc.Name = "dgvThuoc"
        Me.dgvThuoc.RowHeadersWidth = 51
        Me.dgvThuoc.RowTemplate.Height = 24
        Me.dgvThuoc.Size = New System.Drawing.Size(240, 150)
        Me.dgvThuoc.TabIndex = 0
        '
        'txtMaThuoc
        '
        Me.txtMaThuoc.Location = New System.Drawing.Point(58, 196)
        Me.txtMaThuoc.Name = "txtMaThuoc"
        Me.txtMaThuoc.Size = New System.Drawing.Size(126, 22)
        Me.txtMaThuoc.TabIndex = 1
        '
        'txtTenThuoc
        '
        Me.txtTenThuoc.Location = New System.Drawing.Point(48, 251)
        Me.txtTenThuoc.Name = "txtTenThuoc"
        Me.txtTenThuoc.Size = New System.Drawing.Size(156, 22)
        Me.txtTenThuoc.TabIndex = 2
        '
        'txtDonVi
        '
        Me.txtDonVi.Location = New System.Drawing.Point(48, 357)
        Me.txtDonVi.Name = "txtDonVi"
        Me.txtDonVi.Size = New System.Drawing.Size(129, 22)
        Me.txtDonVi.TabIndex = 3
        '
        'txtHoaChat
        '
        Me.txtHoaChat.Location = New System.Drawing.Point(58, 303)
        Me.txtHoaChat.Name = "txtHoaChat"
        Me.txtHoaChat.Size = New System.Drawing.Size(156, 22)
        Me.txtHoaChat.TabIndex = 4
        '
        'txtGiaBan
        '
        Me.txtGiaBan.Location = New System.Drawing.Point(48, 418)
        Me.txtGiaBan.Name = "txtGiaBan"
        Me.txtGiaBan.Size = New System.Drawing.Size(156, 22)
        Me.txtGiaBan.TabIndex = 5
        '
        'txtSoLuong
        '
        Me.txtSoLuong.Location = New System.Drawing.Point(48, 476)
        Me.txtSoLuong.Name = "txtSoLuong"
        Me.txtSoLuong.Size = New System.Drawing.Size(156, 22)
        Me.txtSoLuong.TabIndex = 6
        '
        'dtpHanDung
        '
        Me.dtpHanDung.Location = New System.Drawing.Point(310, 444)
        Me.dtpHanDung.Name = "dtpHanDung"
        Me.dtpHanDung.Size = New System.Drawing.Size(245, 22)
        Me.dtpHanDung.TabIndex = 7
        '
        'cmbNhaCungCap
        '
        Me.cmbNhaCungCap.FormattingEnabled = True
        Me.cmbNhaCungCap.Location = New System.Drawing.Point(310, 243)
        Me.cmbNhaCungCap.Name = "cmbNhaCungCap"
        Me.cmbNhaCungCap.Size = New System.Drawing.Size(147, 24)
        Me.cmbNhaCungCap.TabIndex = 8
        '
        'btnThem
        '
        Me.btnThem.Location = New System.Drawing.Point(817, 180)
        Me.btnThem.Name = "btnThem"
        Me.btnThem.Size = New System.Drawing.Size(115, 38)
        Me.btnThem.TabIndex = 9
        Me.btnThem.Text = "Thêm"
        Me.btnThem.UseVisualStyleBackColor = True
        '
        'btnSua
        '
        Me.btnSua.Location = New System.Drawing.Point(817, 235)
        Me.btnSua.Name = "btnSua"
        Me.btnSua.Size = New System.Drawing.Size(115, 38)
        Me.btnSua.TabIndex = 10
        Me.btnSua.Text = "Sửa"
        Me.btnSua.UseVisualStyleBackColor = True
        '
        'btnXoa
        '
        Me.btnXoa.Location = New System.Drawing.Point(817, 303)
        Me.btnXoa.Name = "btnXoa"
        Me.btnXoa.Size = New System.Drawing.Size(115, 38)
        Me.btnXoa.TabIndex = 11
        Me.btnXoa.Text = "Xóa"
        Me.btnXoa.UseVisualStyleBackColor = True
        '
        'btnLuu
        '
        Me.btnLuu.Location = New System.Drawing.Point(817, 370)
        Me.btnLuu.Name = "btnLuu"
        Me.btnLuu.Size = New System.Drawing.Size(115, 38)
        Me.btnLuu.TabIndex = 12
        Me.btnLuu.Text = "Lưu"
        Me.btnLuu.UseVisualStyleBackColor = True
        '
        'btnHuy
        '
        Me.btnHuy.Location = New System.Drawing.Point(817, 438)
        Me.btnHuy.Name = "btnHuy"
        Me.btnHuy.Size = New System.Drawing.Size(115, 38)
        Me.btnHuy.TabIndex = 13
        Me.btnHuy.Text = "Hủy"
        Me.btnHuy.UseVisualStyleBackColor = True
        '
        'btnTimKiem
        '
        Me.btnTimKiem.Location = New System.Drawing.Point(817, 502)
        Me.btnTimKiem.Name = "btnTimKiem"
        Me.btnTimKiem.Size = New System.Drawing.Size(115, 38)
        Me.btnTimKiem.TabIndex = 14
        Me.btnTimKiem.Text = "Tìm kiếm"
        Me.btnTimKiem.UseVisualStyleBackColor = True
        '
        'FormThuoc
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1028, 570)
        Me.Controls.Add(Me.btnTimKiem)
        Me.Controls.Add(Me.btnHuy)
        Me.Controls.Add(Me.btnLuu)
        Me.Controls.Add(Me.btnXoa)
        Me.Controls.Add(Me.btnSua)
        Me.Controls.Add(Me.btnThem)
        Me.Controls.Add(Me.cmbNhaCungCap)
        Me.Controls.Add(Me.dtpHanDung)
        Me.Controls.Add(Me.txtSoLuong)
        Me.Controls.Add(Me.txtGiaBan)
        Me.Controls.Add(Me.txtHoaChat)
        Me.Controls.Add(Me.txtDonVi)
        Me.Controls.Add(Me.txtTenThuoc)
        Me.Controls.Add(Me.txtMaThuoc)
        Me.Controls.Add(Me.dgvThuoc)
        Me.Name = "FormThuoc"
        Me.Text = "FormThuoc"
        CType(Me.dgvThuoc, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents dgvThuoc As DataGridView
    Friend WithEvents txtMaThuoc As TextBox
    Friend WithEvents txtTenThuoc As TextBox
    Friend WithEvents txtDonVi As TextBox
    Friend WithEvents txtHoaChat As TextBox
    Friend WithEvents txtGiaBan As TextBox
    Friend WithEvents txtSoLuong As TextBox
    Friend WithEvents dtpHanDung As DateTimePicker
    Friend WithEvents cmbNhaCungCap As ComboBox
    Friend WithEvents btnThem As Button
    Friend WithEvents btnSua As Button
    Friend WithEvents btnXoa As Button
    Friend WithEvents btnLuu As Button
    Friend WithEvents btnHuy As Button
    Friend WithEvents btnTimKiem As Button
End Class
