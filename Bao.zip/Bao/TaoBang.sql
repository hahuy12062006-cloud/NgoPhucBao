﻿
 CREATE DATABASE QuanLyNhaThuoc;
 GO
-- USE QuanLyNhaThuoc;
-- GO

-- 1. Bảng NHOM_THUOC (Phân loại thuốc)
CREATE TABLE NHOM_THUOC (
    MaNhom      VARCHAR(10) PRIMARY KEY,
    TenNhom     NVARCHAR(50) NOT NULL
);

-- 2. Bảng NHA_CUNG_CAP (Thông tin nhà cung cấp)
CREATE TABLE NHA_CUNG_CAP (
    MaNCC       VARCHAR(10) PRIMARY KEY,
    TenNCC      NVARCHAR(100) NOT NULL,
    DiaChi      NVARCHAR(200),
    SoDienThoai VARCHAR(15)
);

-- 3. Bảng NHAN_VIEN (Thông tin nhân viên)
CREATE TABLE NHAN_VIEN (
    MaNV        VARCHAR(10) PRIMARY KEY,
    TenNV       NVARCHAR(100) NOT NULL,
    ChucVu      NVARCHAR(50),
    SoDienThoai VARCHAR(15)
);

-- 4. Bảng KHACH_HANG (Thông tin khách hàng)
CREATE TABLE KHACH_HANG (
    MaKH        VARCHAR(10) PRIMARY KEY,
    TenKH       NVARCHAR(100),
    SoDienThoai VARCHAR(15),
    DiemTichLuy INT DEFAULT 0
);

-- 5. Bảng THUOC (Thông tin chi tiết về thuốc)
CREATE TABLE THUOC (
    MaThuoc     VARCHAR(10) PRIMARY KEY,
    TenThuoc    NVARCHAR(100) NOT NULL,
    HoatChat    NVARCHAR(100) NOT NULL,
    DonViTinh   NVARCHAR(20) NOT NULL,
    GiaBanLe    MONEY NOT NULL CHECK (GiaBanLe >= 0),
    MaNhom      VARCHAR(10) NOT NULL,
    HanSuDung   DATE,
    GhiChu      NVARCHAR(255),
    -- Khóa ngoại liên kết với NHOM_THUOC
    FOREIGN KEY (MaNhom) REFERENCES NHOM_THUOC(MaNhom)
);